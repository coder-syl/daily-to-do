<template>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
  >
    <el-table-column label="end-date" prop="endDate" width="160"></el-table-column>
    <el-table-column label="to-do-list" prop="name"></el-table-column>
    <el-table-column
      prop="importance"
      label="重要度"
      width="150"
      :filters="[{ text: '重要且紧急', value: '重要且紧急' }, { text: '重要不紧急', value: '重要不紧急' },{text: '紧急且重要', value: '紧急且重要'},{ text: '紧急不重要', value: '紧急不重要'}]"
      :filter-method="filterTag"
      filter-placement="bottom-end"
    >
      <template slot-scope="scope">
        <el-tag
          :type="scope.row.tag === '重要且紧急' ? 'primary' : 'success'"
          disable-transitions
        >{{scope.row.importance}}</el-tag>
      </template>
    </el-table-column>
    <el-table-column align="right">
      <template slot="header" slot-scope="scope">
        <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
      </template>
      <template slot-scope="scope">
        <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">Edit</el-button>
        <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row,2)">Delete</el-button>
        <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row,1)">加入完成</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  data() {
    return {
      tableData: [],
      search: ""
    };
  },
  mounted() {
    this.iniData();
  },
  methods: {
    filterTag(value, row) {
      return row.tag === value;
    },
    /** 初始化数据，读取json赋值给tableData */
    iniData() {
      this.tableData = this.$db
        .get("toDo")
        .filter({ flag: 0 })
        .sortBy("endDate")
        .value();
      console.log(this.tableData);
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    handleDelete(index, row, flag) {
      console.log(index, row);
      let result = this.$db
        .get("toDo")
        .find({ id: row.id })
        .assign({ flag: flag })
        .write();
      if (result) {
        this.$message({
          message: "操作成功",
          type: "success"
        });
        this.iniData();
      } else {
        this.$message({
          message: "操作失败",
          type: "warning"
        });
        this.iniData();
      }
    }
  }
};
</script>